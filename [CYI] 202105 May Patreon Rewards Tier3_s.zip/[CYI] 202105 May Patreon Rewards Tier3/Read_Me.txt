Hi guys, this is CYI.
There are a few things to be told here.

**For the rights of every buyer and author**
1. Please do not upload these files on the Internet.
2. High resolution pictures are for your personal use only.
3. You can print my work as an individual.
For example, you can print it as a poster, or you can print some small things for your own use.
4. In addition, please do not sell it or redistribute the file.

Every illustration is completed by the love of the author and the support of everyone, please cherish it, I will continue to draw, thank you!

-------------------------

嗨，我是CYI。
在這邊要告知一些事情。

**為了每一位購買者與作者權益**
1.請不要在互聯網上上傳這些文件。
2.高分辨率圖片僅供您個人使用。
3.您可以將我的作品作為個人打印。
例如，您可以將其打印為海報，也可以打印一些小東西供自己使用。
4.另外，請不要出售它，也不要重新分發文件。

每張插畫都是由作者的愛與大家的支持才完成的，請好好珍惜，我也會持續畫下去，謝謝！


-------------------------

嗨，我是CYI。
在这边要告知一些事情。

**为了每一位购买者与作者权益**
1.请不要在互联网上上传这些文件。
2.高分辨率图片仅供您个人使用。
3.您可以将我的作品作为个人打印。
例如，您可以将其打印为海报，也可以打印一些小东西供自己使用。
4.另外，请不要出售它，也不要重新分发文件。

每张插画都是由作者的爱与大家的支持才完成的，请好好珍惜，我也会持续画下去，谢谢！

-------------------------

こんにちは、CYIです。
ここで言うべきことがいくつかあります。

**すべての購入者と著者の権利について**
1.これらのファイルをインターネットにアップロードしないでください。
2.高解像度の写真は個人的な使用のみを目的としています。
3.私の作品を個人として印刷できます。
たとえば、ポスターとして印刷したり、自分用に小さなものを印刷したりできます。
4.また、ファイルを販売したり再配布したりしないでください。

イラストはすべて作者の愛と皆様のご愛顧により完成しておりますので、よろしくお願いいたします。今後ともよろしくお願いいたします！